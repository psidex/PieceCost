# Piece Cost

A simple web extension to add the £ cost per lego piece to lego sets on lego's website.

Currently only supports £.

## Example

![demo image](./demo.png)
